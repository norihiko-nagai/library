<?php
require_once('../../../../wp-load.php');
if (!current_user_can('manage_options')) {
    wp_die('アクセス拒否');
}
if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'outline_checker_nonce')) {
    wp_die('不正なリクエストです。');
}

$results = json_decode(file_get_contents('cache.json'), true);
if (!$results) wp_die('データがありません');

header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=outline.csv");

$fp = fopen('php://output', 'w');
fputcsv($fp, ['タイトル', 'スラッグ', 'URL', 'アウトライン']);
foreach ($results as $row) {
    fputcsv($fp, $row);
}
fclose($fp);
exit;
