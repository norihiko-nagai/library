<?php
/**
 * Plugin-style standalone tool to check HTML heading outline across all pages.
 * Secure version: includes CSRF protection, cURL, and admin check.
 */
define('WP_USE_THEMES', false);
require_once('../../../../wp-load.php');

if (!current_user_can('manage_options')) {
    wp_die('アクセス権限がありません。');
}

$nonce = wp_create_nonce('outline_checker_nonce');
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>HTMLアウトラインチェックツール</title>
    <style>
        body { font-family: sans-serif; padding: 2em; }
        table { border-collapse: collapse; width: 100%; margin-top: 1em; }
        th, td { border: 1px solid #ccc; padding: 0.5em; }
        th { background: #f0f0f0; }
    </style>
    <?php wp_enqueue_script('jquery'); ?>
</head>
<body>
    <h1>HTMLアウトラインチェック</h1>
    <button id="start-scan">解析開始</button>
    <form method="post" action="download.php">
        <input type="hidden" name="nonce" value="<?php echo esc_attr($nonce); ?>">
        <input type="submit" value="CSVをダウンロード">
    </form>
    <div id="result"></div>

<script>
jQuery(document).ready(function($) {
    $('#start-scan').click(function() {
        $('#result').html('<p>解析中...</p>');
        $.post('scan.php', { nonce: '<?php echo esc_js($nonce); ?>' }, function(response) {
            $('#result').html(response);
        });
    });
});
</script>
</body>
</html>
