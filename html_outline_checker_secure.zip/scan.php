<?php
require_once('../../../../wp-load.php');

if (!current_user_can('manage_options')) {
    wp_die('権限がありません。');
}
if (!check_ajax_referer('outline_checker_nonce', 'nonce', false)) {
    wp_die('不正なリクエストです。');
}

$pages = get_pages();
$results = [];
foreach ($pages as $page) {
    $url = get_permalink($page->ID);
    $html = fetch_html($url);
    $headings = [];
    if ($html) {
        preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\1>/i', $html, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $headings[] = 'h' . $match[1] . ': ' . strip_tags($match[2]);
        }
    }
    $results[] = [
        'title' => $page->post_title,
        'slug'  => $page->post_name,
        'url'   => $url,
        'outline' => implode(" / ", $headings)
    ];
}

file_put_contents('cache.json', json_encode($results));
echo '<table><tr><th>タイトル</th><th>スラッグ</th><th>URL</th><th>アウトライン</th></tr>';
foreach ($results as $row) {
    echo '<tr>';
    echo '<td>' . esc_html($row['title']) . '</td>';
    echo '<td>' . esc_html($row['slug']) . '</td>';
    echo '<td><a href="' . esc_url($row['url']) . '" target="_blank">' . esc_html($row['url']) . '</a></td>';
    echo '<td>' . esc_html($row['outline']) . '</td>';
    echo '</tr>';
}
echo '</table>';

function fetch_html($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $html = curl_exec($ch);
    curl_close($ch);
    return $html;
}
