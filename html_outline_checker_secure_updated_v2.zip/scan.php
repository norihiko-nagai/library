<?php
require_once('../../wp-load.php');
if (!is_user_logged_in()) {
    auth_redirect();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['urls'])) {
    $urls = explode("\n", trim($_POST['urls']));
    $results = [];
    foreach ($urls as $url) {
        $url = trim($url);
        if (empty($url)) continue;
        $html = @file_get_contents($url);
        if ($html === false) continue;
        $doc = new DOMDocument();
        @$doc->loadHTML($html);
        $xpath = new DOMXPath($doc);
        $headings = [];
        foreach (['h1','h2','h3','h4','h5','h6'] as $tag) {
            foreach ($xpath->query("//{$tag}") as $node) {
                $headings[] = "{$tag}: " . trim($node->textContent);
            }
        }
        $results[] = [
            'url' => $url,
            'outline' => $headings
        ];
    }
    file_put_contents(__DIR__ . '/data.json', json_encode($results, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}
header('Location: index.php');
exit;
?>
