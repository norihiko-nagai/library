<?php
require_once('../../wp-load.php');
if (!is_user_logged_in()) {
    auth_redirect();
}
$data_file = __DIR__ . '/data.json';
$data = [];
if (file_exists($data_file)) {
    $data = json_decode(file_get_contents($data_file), true);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>HTMLアウトラインチェッカー</title>
    <style>
        body { font-family: sans-serif; padding: 20px; }
        table { border-collapse: collapse; width: 100%; table-layout: fixed; }
        th, td { border: 1px solid #ccc; padding: 8px; word-break: break-word; }
        th { background: #f5f5f5; }
    </style>
</head>
<body>
    <h1>HTMLアウトラインチェッカー</h1>
    <form method="post" action="scan.php">
        <label>URL一覧（改行区切り）</label><br>
        <textarea name="urls" rows="10" cols="100"></textarea><br>
        <button type="submit">スキャン開始</button>
    </form>
    <p><a href="download-csv.php?download=csv">CSVをダウンロード</a></p>
    <table>
        <thead>
            <tr>
                <th>URL</th>
                <?php
                $max = 0;
                foreach ($data as $row) {
                    if (count($row['outline']) > $max) $max = count($row['outline']);
                }
                for ($i = 1; $i <= $max; $i++) {
                    echo "<th>Heading {$i}</th>";
                }
                ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['url']); ?></td>
                    <?php
                    $outline = array_pad($row['outline'], $max, '');
                    foreach ($outline as $item) {
                        echo '<td>' . htmlspecialchars($item) . '</td>';
                    }
                    ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
