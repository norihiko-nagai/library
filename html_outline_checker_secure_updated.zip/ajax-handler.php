<?php
require_once('../../wp-load.php');
if (!is_user_logged_in()) {
    wp_send_json_error('ログインが必要です');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = file_get_contents('php://input');
    file_put_contents(__DIR__ . '/data.json', $json);
    wp_send_json_success('保存しました');
}
?>
