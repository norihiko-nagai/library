<?php
if (isset($_GET['download']) && $_GET['download'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="html_outline_report.csv"');

    $output = fopen('php://output', 'w');

    $data = json_decode(file_get_contents(__DIR__ . '/data.json'), true);

    $max_headers = 0;
    foreach ($data as $row) {
        $count = count($row['outline']);
        if ($count > $max_headers) {
            $max_headers = $count;
        }
    }

    $headers = ['URL'];
    for ($i = 1; $i <= $max_headers; $i++) {
        $headers[] = "Heading $i";
    }
    fputcsv($output, $headers);

    foreach ($data as $row) {
        $url = $row['url'];
        $outlines = $row['outline'];
        $outline_cells = array_pad($outlines, $max_headers, '');
        fputcsv($output, array_merge([$url], $outline_cells));
    }

    fclose($output);
    exit;
}
?>
