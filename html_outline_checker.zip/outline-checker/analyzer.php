<?php
function analyze_pages($urls) {
    $results = [];
    foreach ($urls as $url) {
        $html = @file_get_contents($url);
        if (!$html) continue;

        $dom = new DOMDocument();
        @$dom->loadHTML($html);
        $headings = [];
        $issues = [];
        $prev_level = 0;

        foreach (['h1','h2','h3','h4','h5','h6'] as $tag) {
            $elements = $dom->getElementsByTagName($tag);
            foreach ($elements as $el) {
                $level = intval(substr($tag, 1));
                $headings[] = $tag . ': ' . trim($el->nodeValue);

                if ($tag === 'h1' && isset($found_h1)) {
                    $issues[] = 'h1が複数存在';
                }
                if ($tag === 'h1') $found_h1 = true;

                if ($prev_level && ($level > $prev_level + 1)) {
                    $issues[] = $tag . 'の前に' . 'h' . ($level - 1) . 'が必要';
                }
                $prev_level = $level;
            }
        }
        if (!isset($found_h1)) $issues[] = 'h1が存在しない';

        $results[] = ['url' => $url, 'headings' => $headings, 'issues' => $issues];
    }
    return $results;
}
