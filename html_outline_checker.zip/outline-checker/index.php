<?php
require_once 'crawler.php';
require_once 'analyzer.php';
require_once 'utils.php';

if (!is_admin_logged_in()) {
    http_response_code(403);
    echo "Access Denied";
    exit;
}

$start_url = get_site_url();
$urls = crawl_site($start_url);
$results = analyze_pages($urls);

if (isset($_GET['csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=outline_report.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['URL', 'Headings', 'Issues']);
    foreach ($results as $res) {
        fputcsv($output, [$res['url'], implode(', ', $res['headings']), implode(', ', $res['issues'])]);
    }
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>HTML Outline Checker</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>HTML Outline Checker</h1>
<p><a href="?csv=1" class="csv-btn">CSV出力</a></p>
<table>
    <thead>
        <tr><th>URL</th><th>見出し構造</th><th>検出された問題</th></tr>
    </thead>
    <tbody>
        <?php foreach ($results as $res): ?>
        <tr>
            <td><?= htmlspecialchars($res['url']) ?></td>
            <td><?= htmlspecialchars(implode(', ', $res['headings'])) ?></td>
            <td><?= htmlspecialchars(implode(', ', $res['issues'])) ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</body>
</html>
