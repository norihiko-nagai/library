<?php
function normalize_url($link, $base) {
    if (strpos($link, 'http') === 0) return $link;
    if (strpos($link, '/') === 0) {
        $parsed = parse_url($base);
        return $parsed['scheme'] . '://' . $parsed['host'] . $link;
    }
    return rtrim($base, '/') . '/' . ltrim($link, '/');
}

function is_admin_logged_in() {
    if (!function_exists('is_user_logged_in')) require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');
    return function_exists('current_user_can') && current_user_can('manage_options');
}

function get_site_url() {
    if (!function_exists('get_site_url')) require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');
    return get_site_url();
}
