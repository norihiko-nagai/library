<?php
function crawl_site($start_url, $limit = 100) {
    $queue = [$start_url];
    $seen = [$start_url => true];
    $results = [];

    while ($url = array_shift($queue)) {
        $results[] = $url;
        if (count($results) >= $limit) break;

        $html = @file_get_contents($url);
        if (!$html) continue;

        preg_match_all('/<a\s[^>]*href=["\']?([^"\'>]+)["\']?/i', $html, $matches);
        foreach ($matches[1] as $link) {
            $absolute = normalize_url($link, $start_url);
            if (strpos($absolute, $start_url) === 0 && !isset($seen[$absolute])) {
                $seen[$absolute] = true;
                $queue[] = $absolute;
            }
        }
    }
    return $results;
}
